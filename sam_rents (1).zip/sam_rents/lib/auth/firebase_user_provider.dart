import 'package:firebase_auth/firebase_auth.dart';
import 'package:rxdart/rxdart.dart';

class SamRentsFirebaseUser {
  SamRentsFirebaseUser(this.user);
  User user;
  bool get loggedIn => user != null;
}

SamRentsFirebaseUser currentUser;
bool get loggedIn => currentUser?.loggedIn ?? false;
Stream<SamRentsFirebaseUser> samRentsFirebaseUserStream() =>
    FirebaseAuth.instance
        .authStateChanges()
        .debounce((user) => user == null && !loggedIn
            ? TimerStream(true, const Duration(seconds: 1))
            : Stream.value(user))
        .map<SamRentsFirebaseUser>(
            (user) => currentUser = SamRentsFirebaseUser(user));
