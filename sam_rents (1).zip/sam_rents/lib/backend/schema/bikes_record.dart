import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'bikes_record.g.dart';

abstract class BikesRecord implements Built<BikesRecord, BikesRecordBuilder> {
  static Serializer<BikesRecord> get serializer => _$bikesRecordSerializer;

  @nullable
  String get bikeName;

  @nullable
  String get bikeNumber;

  @nullable
  String get bikeColor;

  @nullable
  String get bikeEngine;

  @nullable
  String get bikePower;

  @nullable
  String get bikeWeight;

  @nullable
  bool get bikeAvailable;

  @nullable
  String get bikePhoto;

  @nullable
  DocumentReference get bikeUser;

  @nullable
  String get bikeDesp;

  @nullable
  String get bikeCity;

  @nullable
  DocumentReference get bikePayment;

  @nullable
  int get bikePricePerDay;

  @nullable
  int get bikeRatings;

  @nullable
  DocumentReference get bikecites;

  @nullable
  String get isBike;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(BikesRecordBuilder builder) => builder
    ..bikeName = ''
    ..bikeNumber = ''
    ..bikeColor = ''
    ..bikeEngine = ''
    ..bikePower = ''
    ..bikeWeight = ''
    ..bikeAvailable = false
    ..bikePhoto = ''
    ..bikeDesp = ''
    ..bikeCity = ''
    ..bikePricePerDay = 0
    ..bikeRatings = 0
    ..isBike = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('bikes');

  static Stream<BikesRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<BikesRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  BikesRecord._();
  factory BikesRecord([void Function(BikesRecordBuilder) updates]) =
      _$BikesRecord;

  static BikesRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createBikesRecordData({
  String bikeName,
  String bikeNumber,
  String bikeColor,
  String bikeEngine,
  String bikePower,
  String bikeWeight,
  bool bikeAvailable,
  String bikePhoto,
  DocumentReference bikeUser,
  String bikeDesp,
  String bikeCity,
  DocumentReference bikePayment,
  int bikePricePerDay,
  int bikeRatings,
  DocumentReference bikecites,
  String isBike,
}) =>
    serializers.toFirestore(
        BikesRecord.serializer,
        BikesRecord((b) => b
          ..bikeName = bikeName
          ..bikeNumber = bikeNumber
          ..bikeColor = bikeColor
          ..bikeEngine = bikeEngine
          ..bikePower = bikePower
          ..bikeWeight = bikeWeight
          ..bikeAvailable = bikeAvailable
          ..bikePhoto = bikePhoto
          ..bikeUser = bikeUser
          ..bikeDesp = bikeDesp
          ..bikeCity = bikeCity
          ..bikePayment = bikePayment
          ..bikePricePerDay = bikePricePerDay
          ..bikeRatings = bikeRatings
          ..bikecites = bikecites
          ..isBike = isBike));
