import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import '../backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../auth/auth_util.dart';

String multiplicationMethod(
  int noOfDaysCF,
  int pricePerDayCF,
) {
  int res = noOfDaysCF * pricePerDayCF;
  String res1 = res.toString();

  res1 = res1.replaceAll(RegExp(r'\D'), '');
  res1 = res1.replaceAll(RegExp(r'\B(?=(\d{3})+(?!\d))'), ',');
  return res1;
}

String addingReturnDate(
  DateTime pickupDate,
  int intDays,
) {
  // add int to date
  String formatteds;
  final DateFormat formatter = DateFormat('dd/MM/yyyy');
  if (intDays != null) {
    pickupDate = pickupDate.add(Duration(days: intDays));
    formatteds = formatter.format(pickupDate);
  }
  return formatteds;
}
