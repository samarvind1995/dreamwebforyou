import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'recent_rents_record.g.dart';

abstract class RecentRentsRecord
    implements Built<RecentRentsRecord, RecentRentsRecordBuilder> {
  static Serializer<RecentRentsRecord> get serializer =>
      _$recentRentsRecordSerializer;

  @nullable
  DocumentReference get bikeCity;

  @nullable
  String get totalPrice;

  @nullable
  String get returnDate;

  @nullable
  String get bikeName;

  @nullable
  String get userName;

  @nullable
  String get bikepic;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(RecentRentsRecordBuilder builder) => builder
    ..totalPrice = ''
    ..returnDate = ''
    ..bikeName = ''
    ..userName = ''
    ..bikepic = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('recentRents');

  static Stream<RecentRentsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<RecentRentsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  RecentRentsRecord._();
  factory RecentRentsRecord([void Function(RecentRentsRecordBuilder) updates]) =
      _$RecentRentsRecord;

  static RecentRentsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createRecentRentsRecordData({
  DocumentReference bikeCity,
  String totalPrice,
  String returnDate,
  String bikeName,
  String userName,
  String bikepic,
}) =>
    serializers.toFirestore(
        RecentRentsRecord.serializer,
        RecentRentsRecord((r) => r
          ..bikeCity = bikeCity
          ..totalPrice = totalPrice
          ..returnDate = returnDate
          ..bikeName = bikeName
          ..userName = userName
          ..bikepic = bikepic));
